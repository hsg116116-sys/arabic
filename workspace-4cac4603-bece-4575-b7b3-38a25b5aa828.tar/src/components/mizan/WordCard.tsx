"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, BookOpen, Layers, Scale, Lightbulb } from "lucide-react";
import type { WordEntry } from "@/lib/mizan-data";

interface WordCardProps {
  entry: WordEntry;
}

/**
 * بطاقة تحليل الكلمة - تعرض المعلومات تدريجيًا حتى يرى الطالب طريقة التفكير، لا النتيجة فقط.
 */
export function WordCard({ entry }: WordCardProps) {
  // عدد الخطوات التي ظهرت للطالب (تدريجي)
  const [revealedSteps, setRevealedSteps] = useState(0);
  // هل ظهر المعلومات النهائية (الوزن، الجذر، الزيادة)؟
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    let cancelled = false;

    // إعادة التهيئة عند تغيير الكلمة - داخل مؤقت لتجنب التحديث المتزامن
    const resetTimer = setTimeout(() => {
      if (!cancelled) {
        setRevealedSteps(0);
        setShowResult(false);
      }
    }, 0);

    const timers: ReturnType<typeof setTimeout>[] = [resetTimer];
    // إظهار الخطوات تدريجيًا، خطوة كل 900 مللي ثانية
    entry.steps.forEach((_, i) => {
      timers.push(
        setTimeout(() => {
          if (!cancelled) setRevealedSteps(i + 1);
        }, 600 + i * 900)
      );
    });
    // إظهار النتيجة بعد آخر خطوة
    timers.push(
      setTimeout(() => {
        if (!cancelled) setShowResult(true);
      }, 600 + entry.steps.length * 900 + 400)
    );

    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [entry.id, entry.steps.length]);

  return (
    <motion.div
      key={entry.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="bg-card border border-border rounded-2xl shadow-lg overflow-hidden"
      dir="rtl"
    >
      {/* رأس البطاقة - الكلمة */}
      <div className="relative px-6 py-5 bg-gradient-to-l from-navy-soft to-card border-b border-border">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <div className="text-xs text-muted-foreground mb-1">الكلمة المُوزونة</div>
            <div className="text-5xl font-bold font-cairo text-navy">
              {entry.display}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge>{entry.type}</Badge>
            <Badge>{entry.form}</Badge>
            <Badge>{entry.category}</Badge>
          </div>
        </div>
      </div>

      {/* النتيجة - تظهر تدريجيًا */}
      <AnimatePresence>
        {showResult && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border"
          >
            <ResultCell
              icon={<Layers className="w-4 h-4" />}
              label="الحروف الأصلية"
              value={entry.root}
              tone="original"
            />
            <ResultCell
              icon={<Scale className="w-4 h-4" />}
              label="الوزن الصرفي"
              value={entry.weight}
              tone="weight"
            />
            <ResultCell
              icon={<Sparkles className="w-4 h-4" />}
              label="حروف الزيادة"
              value={entry.extraLetters}
              tone="extra"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* خريطة المقابلة بين الحروف والوزن */}
      <AnimatePresence>
        {showResult && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.4 }}
            className="px-6 py-4 border-t border-border"
          >
            <div className="flex items-center gap-2 mb-3">
              <Scale className="w-4 h-4 text-gold" />
              <h4 className="font-semibold text-navy text-sm">
                مقابلة الحروف بالميزان
              </h4>
            </div>
            <div className="flex flex-wrap items-stretch gap-2">
              {entry.mapping.map((m, i) => (
                <MappingChip key={i} m={m} />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* خطوات استخراج الوزن - تظهر تدريجيًا */}
      <div className="px-6 py-5 border-t border-border bg-muted/30">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen className="w-4 h-4 text-navy" />
          <h4 className="font-semibold text-navy text-sm">
            كيف وصلنا إلى الوزن؟
          </h4>
        </div>
        <ol className="space-y-2" dir="rtl">
          {entry.steps.map((step, i) => {
            const visible = i < revealedSteps;
            return (
              <AnimatePresence key={i}>
                {visible && (
                  <motion.li
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex items-start gap-3"
                  >
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-navy text-white text-xs font-bold flex items-center justify-center font-cairo">
                      {i + 1}
                    </span>
                    <span className="text-foreground/90 text-sm md:text-base leading-relaxed pt-0.5">
                      {step}
                    </span>
                  </motion.li>
                )}
              </AnimatePresence>
            );
          })}
        </ol>
      </div>

      {/* ملاحظة تعليمية - اختيارية */}
      <AnimatePresence>
        {showResult && entry.note && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="px-6 py-3 bg-gold-soft/40 border-t border-gold/30 flex items-start gap-2"
          >
            <Lightbulb className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-amber-900/90 leading-relaxed">
              {entry.note}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-navy/10 text-navy border border-navy/20">
      {children}
    </span>
  );
}

const TONE_STYLES = {
  original: "bg-navy/5 border-navy/20",
  extra: "bg-amber-50 border-amber-300/50",
  weight: "bg-gold-soft/50 border-gold/40",
};

function ResultCell({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: keyof typeof TONE_STYLES;
}) {
  return (
    <div className={`p-4 ${TONE_STYLES[tone]} border-l last:border-l-0`}>
      <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
        {icon}
        <span>{label}</span>
      </div>
      <div className="text-xl md:text-2xl font-bold font-cairo text-navy">
        {value}
      </div>
    </div>
  );
}

const KIND_COLORS = {
  original: { bg: "bg-navy/10", text: "text-navy", border: "border-navy/30", label: "أصلي" },
  extra: { bg: "bg-amber-50", text: "text-amber-800", border: "border-amber-300", label: "زائد" },
  transformed: { bg: "bg-purple-50", text: "text-purple-800", border: "border-purple-300", label: "مُغيَّر" },
};

function MappingChip({ m }: { m: WordEntry["mapping"][number] }) {
  const c = KIND_COLORS[m.kind];
  return (
    <div className={`flex flex-col items-center px-3 py-2 rounded-lg border ${c.bg} ${c.border}`}>
      <div className="flex items-baseline gap-1">
        <span className={`text-2xl font-bold font-cairo ${c.text}`}>{m.surface}</span>
        <span className="text-xs text-muted-foreground">←</span>
        <span className="text-base font-cairo text-foreground/70">{m.scale}</span>
      </div>
      <span className={`text-[10px] mt-0.5 ${c.text} opacity-70`}>{c.label}</span>
      {m.note && (
        <span className="text-[10px] text-muted-foreground mt-0.5 text-center">{m.note}</span>
      )}
    </div>
  );
}
