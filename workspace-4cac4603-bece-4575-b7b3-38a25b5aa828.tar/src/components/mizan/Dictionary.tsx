"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, BookOpen, Filter } from "lucide-react";
import { WORDS, CATEGORIES, type WordEntry } from "@/lib/mizan-data";
import { WordCard } from "./WordCard";

export function Dictionary() {
  const [query, setQuery] = useState("");
  const [activeCat, setActiveCat] = useState<string>("all");
  const [selected, setSelected] = useState<WordEntry | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim();
    return WORDS.filter((w) => {
      // مطابقة الفئة
      if (activeCat !== "all") {
        const matches =
          w.type === activeCat ||
          w.form === activeCat ||
          w.category === activeCat;
        if (!matches) return false;
      }
      if (!q) return true;
      // البحث في الكلمة + الجذر + الوزن
      const haystack = [w.word, w.display, w.root, w.weight, w.extraLetters]
        .join(" ")
        .toLowerCase();
      return haystack.includes(q.toLowerCase());
    });
  }, [query, activeCat]);

  return (
    <div className="space-y-6" dir="rtl">
      {/* البحث */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث عن كلمة أو جذر أو وزن..."
          className="w-full bg-card border border-border rounded-xl py-3 pr-12 pl-12 text-base font-cairo focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold transition"
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            className="absolute left-3 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-muted text-muted-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* الفلاتر */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 text-sm text-muted-foreground ml-2">
          <Filter className="w-4 h-4" />
          <span>تصفية:</span>
        </div>
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCat(c.id)}
            className={`px-3 py-1.5 rounded-full text-sm font-semibold transition border ${
              activeCat === c.id
                ? "bg-navy text-white border-navy"
                : "bg-card text-navy border-border hover:border-navy/40"
            }`}
          >
            {c.label}
          </button>
        ))}
        <div className="ml-auto text-sm text-muted-foreground">
          {filtered.length} كلمة
        </div>
      </div>

      {/* قائمة الكلمات */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>لا توجد كلمات مطابقة. جرّب بحثًا آخر.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((w) => (
            <button
              key={w.id}
              onClick={() => setSelected(w)}
              className="text-right bg-card border border-border rounded-xl p-4 hover:border-gold hover:shadow-md transition group"
            >
              <div className="flex items-baseline justify-between gap-2 mb-2">
                <span className="text-3xl font-bold font-cairo text-navy group-hover:text-gold transition">
                  {w.display}
                </span>
                <span className="text-xs text-muted-foreground">
                  {w.type} · {w.form}
                </span>
              </div>
              <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span>
                  <span className="text-navy font-semibold">الجذر:</span> {w.root}
                </span>
                <span>
                  <span className="text-navy font-semibold">الوزن:</span> {w.weight}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* بطاقة التحليل المنبثقة */}
      <AnimatePresence>
        {selected && (
          <div
            className="fixed inset-0 bg-navy/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-2xl w-full max-h-[90vh] overflow-y-auto arabic-scroll"
              onClick={(e) => e.stopPropagation()}
            >
              <WordCard entry={selected} />
              <button
                onClick={() => setSelected(null)}
                className="w-full mt-3 py-3 bg-card border border-border rounded-xl font-semibold text-navy hover:bg-muted transition"
              >
                إغلاق
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
