"use client";

import { motion } from "framer-motion";
import { PenLine, Repeat, Plus, CheckCircle2 } from "lucide-react";

const STEPS = [
  {
    icon: PenLine,
    title: "نحدد الحروف الأصلية",
    desc: "نبحث عن جذر الكلمة: الحروف التي تبقى بعد حذف حروف الزيادة (س أ ل ت م و ن ي هـ ا).",
    example: "كَتَبَ → ك ـ ت ـ ب",
    color: "from-navy to-navy/80",
  },
  {
    icon: Repeat,
    title: "نقابلها بحروف الميزان",
    desc: "نقابل الحرف الأول بـ (فاء)، والثاني بـ (عين)، والثالث بـ (لام)، مع المحافظة على الترتيب والحركات.",
    example: "ك ↔ ف ، ت ↔ ع ، ب ↔ ل",
    color: "from-navy/80 to-navy/60",
  },
  {
    icon: Plus,
    title: "نلاحظ الحروف الزائدة",
    desc: "إذا وجدنا حرفًا من أحرف (سألتمنوها)، نضعه في الميزان في نفس الموضع. وإذا حُذف حرف من الأصل، حُذف ما يقابله في الميزان.",
    example: "أَكْرَمَ → أَ + فْ + عَ + لَ = أَفْعَلَ",
    color: "from-gold to-gold/80",
  },
  {
    icon: CheckCircle2,
    title: "نصل إلى الوزن",
    desc: "بعد المقابلة، نكتب الوزن الصرفي مضبوطًا بحركات الكلمة الأصلية. هذا هو وزن الكلمة على الميزان الصرفي.",
    example: "كَتَبَ ← فَعَلَ",
    color: "from-gold/80 to-gold/60",
  },
];

export function HowToWeigh() {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="text-center">
        <h2 className="text-2xl md:text-3xl font-bold font-cairo text-navy mb-2">
          كيف نزن الكلمة؟
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          الميزان الصرفي أداة بسيطة من أربعة خطوات. تابع الخطوات بالترتيب، وستجد أن وزن أي كلمة يصبح واضحًا.
        </p>
      </div>

      {/* الخطوات */}
      <div className="space-y-4">
        {STEPS.map((s, i) => {
          const Icon = s.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: i * 0.15 }}
              className="flex flex-col md:flex-row items-start gap-4"
            >
              {/* رقم الخطوة + الأيقونة */}
              <div className="flex md:flex-col items-center gap-3 md:gap-2 flex-shrink-0">
                <div
                  className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} text-white flex items-center justify-center shadow-md`}
                >
                  <Icon className="w-7 h-7" />
                </div>
                <span className="text-xs font-bold font-cairo text-navy bg-muted/50 px-2 py-1 rounded-full">
                  خطوة {i + 1}
                </span>
              </div>

              {/* المحتوى */}
              <div className="flex-1 bg-card border border-border rounded-xl p-5">
                <h3 className="font-bold font-cairo text-lg text-navy mb-1">
                  {s.title}
                </h3>
                <p className="text-sm text-foreground/80 leading-relaxed mb-3">
                  {s.desc}
                </p>
                <div className="bg-gold-soft/40 border border-gold/30 rounded-lg px-3 py-2 inline-block">
                  <span className="text-sm font-cairo text-amber-900">
                    <span className="font-semibold">مثال:</span> {s.example}
                  </span>
                </div>
              </div>

              {/* السهم بين الخطوات */}
              {i < STEPS.length - 1 && (
                <div className="hidden md:flex absolute" />
              )}
            </motion.div>
          );
        })}
      </div>

      {/* تنبيه على الكلمات التي لا توزن */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="bg-amber-50 border border-amber-200 rounded-xl p-5"
      >
        <h3 className="font-bold font-cairo text-navy mb-2 flex items-center gap-2">
          <span className="text-amber-700">⚠️</span>
          <span>كلمات لا توزن بالميزان الصرفي</span>
        </h3>
        <ul className="text-sm text-foreground/80 space-y-1.5 leading-relaxed">
          <li>• الأسماء الجامدة (التي لا أصل لها من الأفعال) مثل: <span className="font-cairo font-semibold">أرض، سماء</span>.</li>
          <li>• الأسماء المبنية مثل: <span className="font-cairo font-semibold">هو، هذا، الذي</span>.</li>
          <li>• الأفعال الجامدة مثل: <span className="font-cairo font-semibold">نعم، بئس، عسى</span>.</li>
          <li>• الحروف كلها مثل: <span className="font-cairo font-semibold">في، هل، بل، أو</span>.</li>
        </ul>
      </motion.div>

      {/* خلاصة */}
      <div className="bg-navy text-white rounded-2xl p-6 text-center">
        <p className="text-lg md:text-xl font-cairo leading-relaxed">
          « يَخْتَصُّ الميزانُ الصَّرْفِيُّ بالأفعالِ المتصرِّفةِ والأسماءَ المُشتقَّة »
        </p>
        <p className="text-sm text-white/70 mt-2">
          أي: لا يُوزن به إلا ما له أصل من الفعل المتصرف.
        </p>
      </div>
    </div>
  );
}
