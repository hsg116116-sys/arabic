"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, XCircle, ArrowLeft, Trophy, RotateCcw, Target } from "lucide-react";
import { WORDS, type WordEntry } from "@/lib/mizan-data";

type Level = "تدريب" | "تحدٍّ" | "إتقان";

const LEVELS: { id: Level; label: string; desc: string }[] = [
  { id: "تدريب", label: "تدريب", desc: "كلمات ثلاثية مجردة" },
  { id: "تحدٍّ", label: "تحدٍّ", desc: "كلمات ثلاثية مزيدة ورباعية" },
  { id: "إتقان", label: "إتقان", desc: "كلمات مزيدة وحروف محذوفة" },
];

// تجميع الكلمات حسب المستوى
function pickForLevel(level: Level): WordEntry[] {
  switch (level) {
    case "تدريب":
      return WORDS.filter((w) => w.type === "ثلاثي" && w.form === "مجرد");
    case "تحدٍّ":
      return WORDS.filter(
        (w) =>
          (w.type === "ثلاثي" && w.form === "مزيد") ||
          (w.type === "رباعي" && w.form === "مجرد")
      );
    case "إتقان":
      return WORDS.filter(
        (w) =>
          w.type === "رباعي" && w.form === "مزيد" ||
          w.type === "خماسي" ||
          (w.mapping.some((m) => m.kind === "transformed"))
      );
  }
}

// بناء خيارات إجابة خاطئة من أوزان كلمات أخرى
function buildOptions(correct: WordEntry, pool: WordEntry[]): string[] {
  const correctWeight = correct.weight;
  const distractors = new Set<string>();
  // أضف أوزانًا مختلفة من القاموس
  for (const w of pool) {
    if (w.weight !== correctWeight && distractors.size < 3) {
      distractors.add(w.weight);
    }
    if (distractors.size >= 3) break;
  }
  // إن لم نجد 3، أضف أوزانًا عامة
  const fallback = ["فَعَلَ", "فَعَّلَ", "أَفْعَلَ", "فَعْلَلَ", "تَفَعَّلَ", "اسْتَفْعَلَ", "فَعَّال", "فُعُّول"];
  for (const w of fallback) {
    if (w !== correctWeight && !distractors.has(w)) {
      distractors.add(w);
    }
    if (distractors.size >= 3) break;
  }
  // خلط الخيارات
  const all = [correctWeight, ...Array.from(distractors).slice(0, 3)];
  return all.sort(() => Math.random() - 0.5);
}

interface Question {
  word: WordEntry;
  options: string[];
}

export function Training() {
  const [level, setLevel] = useState<Level | null>(null);
  const [question, setQuestion] = useState<Question | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [total, setTotal] = useState(0);

  const pool = useMemo(() => (level ? pickForLevel(level) : []), [level]);

  function startLevel(l: Level) {
    setLevel(l);
    setScore(0);
    setStreak(0);
    setTotal(0);
    nextQuestion(pickForLevel(l));
  }

  function nextQuestion(p: WordEntry[]) {
    const word = p[Math.floor(Math.random() * p.length)];
    const options = buildOptions(word, p);
    setQuestion({ word, options });
    setSelected(null);
    setAnswered(false);
  }

  function answer(opt: string) {
    if (answered || !question) return;
    setSelected(opt);
    setAnswered(true);
    setTotal((t) => t + 1);
    if (opt === question.word.weight) {
      setScore((s) => s + 1);
      setStreak((s) => s + 1);
    } else {
      setStreak(0);
    }
  }

  function next() {
    if (pool.length === 0) return;
    nextQuestion(pool);
  }

  function backToLevels() {
    setLevel(null);
    setQuestion(null);
  }

  // شاشة اختيار المستوى
  if (!level) {
    return (
      <div className="space-y-6" dir="rtl">
        <div className="text-center">
          <h2 className="text-2xl md:text-3xl font-bold font-cairo text-navy mb-2">
            تحدَّ نفسك
          </h2>
          <p className="text-muted-foreground">
            اختر مستوى التدريب المناسب لك، ثم أجب عن أسئلة الوزن.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {LEVELS.map((l, i) => {
            const count = pickForLevel(l.id).length;
            return (
              <motion.button
                key={l.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                onClick={() => startLevel(l.id)}
                className="text-right bg-card border border-border rounded-2xl p-6 hover:border-gold hover:shadow-lg transition group relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-gold-soft/30 rounded-bl-full opacity-0 group-hover:opacity-100 transition" />
                <div className="relative">
                  <div className="flex items-center justify-between mb-3">
                    <Target className="w-8 h-8 text-gold" />
                    <span className="text-3xl font-bold font-cairo text-navy/20 group-hover:text-gold/50 transition">
                      {i + 1}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold font-cairo text-navy mb-1">
                    {l.label}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-3">{l.desc}</p>
                  <div className="text-xs text-navy/70 bg-muted/50 inline-block px-2 py-1 rounded-full">
                    {count} كلمة متاحة
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    );
  }

  if (!question) return null;

  const isCorrect = selected === question.word.weight;

  return (
    <div className="space-y-6" dir="rtl">
      {/* شريط الحالة */}
      <div className="flex items-center justify-between gap-3 flex-wrap bg-card border border-border rounded-xl p-3">
        <button
          onClick={backToLevels}
          className="flex items-center gap-1.5 text-sm font-semibold text-navy hover:text-gold transition px-3 py-1.5 rounded-lg hover:bg-muted"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>المستويات</span>
        </button>
        <div className="flex items-center gap-3">
          <Stat icon={<CheckCircle2 className="w-4 h-4" />} label="النقاط" value={score} />
          <Stat icon={<Trophy className="w-4 h-4" />} label="المتتالية" value={streak} />
          <Stat icon={<Target className="w-4 h-4" />} label="المستوى" value={level} />
          <Stat icon={<RotateCcw className="w-4 h-4" />} label="المجموع" value={total} />
        </div>
      </div>

      {/* السؤال */}
      <div className="bg-card border border-border rounded-2xl p-6 md:p-8">
        <div className="text-center mb-6">
          <p className="text-sm text-muted-foreground mb-2">ما وزن هذه الكلمة؟</p>
          <motion.div
            key={question.word.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-6xl md:text-7xl font-bold font-cairo text-navy my-4"
          >
            {question.word.display}
          </motion.div>
          <div className="flex justify-center gap-2 flex-wrap text-xs">
            <span className="px-2 py-1 rounded-full bg-muted text-muted-foreground">
              {question.word.type}
            </span>
            <span className="px-2 py-1 rounded-full bg-muted text-muted-foreground">
              {question.word.form}
            </span>
            <span className="px-2 py-1 rounded-full bg-muted text-muted-foreground">
              {question.word.category}
            </span>
          </div>
        </div>

        {/* الخيارات */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {question.options.map((opt) => {
            const isThis = selected === opt;
            const isAnswer = opt === question.word.weight;
            let state: "idle" | "correct" | "wrong" | "dim" = "idle";
            if (answered) {
              if (isAnswer) state = "correct";
              else if (isThis) state = "wrong";
              else state = "dim";
            }
            return (
              <button
                key={opt}
                onClick={() => answer(opt)}
                disabled={answered}
                className={`p-4 rounded-xl border-2 font-cairo text-2xl md:text-3xl font-bold transition flex items-center justify-center gap-2 ${
                  state === "correct"
                    ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                    : state === "wrong"
                    ? "border-red-500 bg-red-50 text-red-700"
                    : state === "dim"
                    ? "border-border bg-muted/30 text-muted-foreground opacity-60"
                    : "border-border bg-card text-navy hover:border-gold hover:bg-gold-soft/30"
                }`}
              >
                {opt}
                {state === "correct" && <CheckCircle2 className="w-5 h-5" />}
                {state === "wrong" && <XCircle className="w-5 h-5" />}
              </button>
            );
          })}
        </div>

        {/* التفسير بعد الإجابة */}
        <AnimatePresence>
          {answered && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-6 overflow-hidden"
            >
              <div
                className={`p-5 rounded-xl border ${
                  isCorrect
                    ? "bg-emerald-50 border-emerald-200"
                    : "bg-amber-50 border-amber-200"
                }`}
              >
                <div className="flex items-center gap-2 mb-3">
                  {isCorrect ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-amber-600" />
                  )}
                  <h4 className="font-bold font-cairo text-lg">
                    {isCorrect ? "إجابة صحيحة! أحسنت." : "إجابة غير صحيحة"}
                  </h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm mb-4">
                  <div className="bg-white/60 rounded-lg p-3">
                    <div className="text-xs text-muted-foreground mb-1">الحروف الأصلية</div>
                    <div className="font-bold font-cairo text-navy text-lg">
                      {question.word.root}
                    </div>
                  </div>
                  <div className="bg-white/60 rounded-lg p-3">
                    <div className="text-xs text-muted-foreground mb-1">الوزن الصحيح</div>
                    <div className="font-bold font-cairo text-navy text-lg">
                      {question.word.weight}
                    </div>
                  </div>
                  <div className="bg-white/60 rounded-lg p-3">
                    <div className="text-xs text-muted-foreground mb-1">حروف الزيادة</div>
                    <div className="font-bold font-cairo text-navy text-lg">
                      {question.word.extraLetters}
                    </div>
                  </div>
                </div>
                <div className="bg-white/60 rounded-lg p-3 mb-4">
                  <div className="text-xs text-muted-foreground mb-1">لماذا؟</div>
                  <p className="text-sm text-foreground/90 leading-relaxed">
                    {question.word.steps[question.word.steps.length - 1]} —{" "}
                    {question.word.steps[0]}
                  </p>
                </div>
                <button
                  onClick={next}
                  className="w-full py-3 bg-navy text-white rounded-xl font-bold font-cairo hover:bg-navy/90 transition flex items-center justify-center gap-2"
                >
                  <span>الكلمة التالية</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function Stat({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
}) {
  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50">
      <span className="text-navy">{icon}</span>
      <div className="flex flex-col leading-tight">
        <span className="text-[10px] text-muted-foreground">{label}</span>
        <span className="text-sm font-bold font-cairo text-navy">{value}</span>
      </div>
    </div>
  );
}
