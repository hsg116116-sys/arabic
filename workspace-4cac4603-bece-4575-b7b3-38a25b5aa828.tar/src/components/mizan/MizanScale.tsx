"use client";

import { motion } from "framer-motion";

interface MizanScaleProps {
  /** حالة الميزان: idle (متوازن) | weighing (يحرك) | done (انتهى) */
  state: "idle" | "weighing" | "done";
  /** الحروف الأصلية للكلمة (لعرضها على كفة اليمين) */
  leftLetters?: string[];
  /** حروف الوزن (ف ع ل) لعرضها على كفة اليسار) */
  rightLetters?: string[];
}

/**
 * الميزان الصرفي - العنصر البصري الرئيسي للموقع.
 * صُمم ليبدو كميزان ذي كفتين، يتحرك طفيفًا عند الوزن ثم يستقر.
 */
export function MizanScale({
  state,
  leftLetters = [],
  rightLetters = [],
}: MizanScaleProps) {
  const tipping = state === "weighing";

  return (
    <div className="relative w-full max-w-2xl mx-auto select-none" dir="rtl">
      {/* قاعدة الميزان */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-48 h-3 bg-gradient-to-r from-navy-soft via-navy to-navy-soft rounded-full shadow-lg" />
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-3 h-10 bg-navy rounded-sm" />

      {/* العمود */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-2 h-32 bg-gradient-to-b from-navy to-navy/80 rounded-full" />

      {/* محتوى الميزان (يُدور قليلًا عند الوزن) */}
      <motion.div
        className="relative pt-4 pb-20"
        animate={{
          rotate: tipping ? [0, -8, 6, -3, 1, 0] : 0,
        }}
        transition={{
          duration: tipping ? 1.4 : 0.4,
          ease: "easeInOut",
        }}
        style={{ transformOrigin: "50% 100%" }}
      >
        {/* المحور العلوي */}
        <div className="absolute top-12 left-1/2 -translate-x-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-gold border-2 border-navy shadow-md z-20" />

        {/* الذراع الأفقي */}
        <div className="absolute top-12 left-0 right-0 h-2 bg-gradient-to-l from-navy via-navy to-navy rounded-full shadow-md" />

        {/* خيوط الكفتين */}
        <div className="absolute top-12 right-[14%] w-px h-16 bg-navy/60" />
        <div className="absolute top-12 right-[14%] w-16 h-px bg-navy/60" style={{ right: "calc(14% - 32px)" }} />
        <div className="absolute top-12 left-[14%] w-px h-16 bg-navy/60" />
        <div className="absolute top-12 left-[14%] w-16 h-px bg-navy/60" style={{ left: "calc(14% - 32px)" }} />

        {/* الكفة اليمنى - الكلمة (الحروف الأصلية) */}
        <Pan side="right" state={state} letters={leftLetters} label="الكلمة" />

        {/* الكفة اليسرى - الوزن (ف ع ل) */}
        <Pan side="left" state={state} letters={rightLetters} label="الوزن" />
      </motion.div>
    </div>
  );
}

function Pan({
  side,
  state,
  letters,
  label,
}: {
  side: "left" | "right";
  state: "idle" | "weighing" | "done";
  letters: string[];
  label: string;
}) {
  const isRight = side === "right";
  const positionClass = isRight ? "right-[6%]" : "left-[6%]";

  return (
    <div className={`absolute top-24 ${positionClass} flex flex-col items-center`}>
      {/* تسمية الكفة */}
      <div
        className={`mb-1 text-xs font-semibold px-2 py-0.5 rounded-full ${
          isRight
            ? "bg-navy-soft text-navy"
            : "bg-gold-soft text-amber-800"
        }`}
      >
        {label}
      </div>

      {/* الكفة - شكل وعاء الميزان */}
      <motion.div
        className={`relative w-44 h-14 rounded-b-3xl rounded-t-md border-2 shadow-lg flex items-center justify-center gap-1 px-2 ${
          state === "done"
            ? "border-gold bg-gold-soft/60"
            : "border-navy bg-card"
        }`}
        animate={{
          y: state === "weighing" ? [0, -4, 2, 0] : 0,
        }}
        transition={{ duration: 1.4, ease: "easeInOut" }}
      >
        {/* الحروف داخل الكفة */}
        {letters.length > 0 ? (
          <div className="flex items-center justify-center gap-2" dir="rtl">
            {letters.map((l, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="text-3xl md:text-4xl font-bold font-cairo text-navy"
              >
                {l}
              </motion.span>
            ))}
          </div>
        ) : (
          <span className="text-muted-foreground/40 text-sm font-cairo">
            —
          </span>
        )}
      </motion.div>
    </div>
  );
}
