"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Scale,
  Search,
  Dumbbell,
  HelpCircle,
  Sparkles,
  AlertCircle,
  RotateCcw,
} from "lucide-react";
import { MizanScale } from "@/components/mizan/MizanScale";
import { WordCard } from "@/components/mizan/WordCard";
import { Dictionary } from "@/components/mizan/Dictionary";
import { Training } from "@/components/mizan/Training";
import { HowToWeigh } from "@/components/mizan/HowToWeigh";
import {
  findWord,
  findNonWeighable,
  type WordEntry,
} from "@/lib/mizan-data";

type View = "main" | "dictionary" | "training" | "howto";

export default function Home() {
  const [view, setView] = useState<View>("main");

  return (
    <div className="min-h-screen flex flex-col bg-background" dir="rtl">
      <Header current={view} onNavigate={setView} />

      <main className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 md:py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
          >
            {view === "main" && <MainLab onNavigate={setView} />}
            {view === "dictionary" && <Dictionary />}
            {view === "training" && <Training />}
            {view === "howto" && <HowToWeigh />}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
}

/* ========== الرأس ========== */
function Header({
  current,
  onNavigate,
}: {
  current: View;
  onNavigate: (v: View) => void;
}) {
  const items: { id: View; label: string; icon: React.ReactNode }[] = [
    { id: "main", label: "الميزان", icon: <Scale className="w-4 h-4" /> },
    { id: "dictionary", label: "معجم الكلمات", icon: <Search className="w-4 h-4" /> },
    { id: "training", label: "تدرّب", icon: <Dumbbell className="w-4 h-4" /> },
    { id: "howto", label: "كيف نزن؟", icon: <HelpCircle className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-5xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* الشعار */}
          <button
            onClick={() => onNavigate("main")}
            className="flex items-center gap-2 group"
          >
            <div className="w-10 h-10 rounded-xl bg-navy text-white flex items-center justify-center group-hover:bg-gold transition">
              <Scale className="w-5 h-5" />
            </div>
            <div className="text-right">
              <div className="font-bold font-cairo text-navy leading-tight">
                مختبر الميزان الصرفي
              </div>
              <div className="text-[10px] text-muted-foreground">
                للصف التاسع
              </div>
            </div>
          </button>

          {/* روابط التنقل */}
          <nav className="hidden md:flex items-center gap-1">
            {items.map((it) => (
              <button
                key={it.id}
                onClick={() => onNavigate(it.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition ${
                  current === it.id
                    ? "bg-navy text-white"
                    : "text-navy hover:bg-muted"
                }`}
              >
                {it.icon}
                <span>{it.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* تنقل الهاتف */}
        <nav className="md:hidden flex items-center gap-1 pb-2 overflow-x-auto arabic-scroll">
          {items.map((it) => (
            <button
              key={it.id}
              onClick={() => onNavigate(it.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                current === it.id
                  ? "bg-navy text-white"
                  : "text-navy hover:bg-muted"
              }`}
            >
              {it.icon}
              <span>{it.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
}

/* ========== الواجهة الرئيسية - المختبر ========== */
function MainLab({ onNavigate }: { onNavigate: (v: View) => void }) {
  const [input, setInput] = useState("");
  const [mizanState, setMizanState] = useState<"idle" | "weighing" | "done">("idle");
  const [result, setResult] = useState<WordEntry | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [leftLetters, setLeftLetters] = useState<string[]>([]);
  const [rightLetters, setRightLetters] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // التركيز على الإدخال عند العودة للواجهة الرئيسية
  useEffect(() => {
    if (inputRef.current) inputRef.current.focus();
  }, []);

  function handleWeigh() {
    const text = input.trim();
    if (!text) return;

    setError(null);
    setResult(null);
    setMizanState("idle");
    setLeftLetters([]);
    setRightLetters([]);

    // التحقق من كلمات جامدة/مبنية أولاً
    const nonWeighable = findNonWeighable(text);
    if (nonWeighable) {
      setError(
        `«${nonWeighable.word}» ${nonWeighable.reason} جرّب كلمة مختلفة.`
      );
      return;
    }

    // البحث في القاموس
    const entry = findWord(text);
    if (!entry) {
      // الكلمة غير موجودة - لا نخمن
      setError(
        "هذه الكلمة تحتاج إلى تحليل آخر. جرّب كلمة مختلفة، أو تصفّح المعجم لاختيار كلمة مدروسة."
      );
      return;
    }

    // وجدنا الكلمة - شغّل الميزان
    setMizanState("weighing");

    // بعد انتهاء حركة الميزان، اعرض الحروف على الكفتين تدريجيًا
    setTimeout(() => {
      // الحروف الأصلية للعرض على كفة الكلمة
      const rootLetters = entry.root
        .replace(/\s/g, "")
        .split("")
        .filter(Boolean);
      // حروف الوزن (ف ع ل) للعرض على كفة الوزن
      const weightLetters = entry.weight
        .replace(/[\u064B-\u065F\u0670]/g, "")
        .split("")
        .filter(Boolean);
      setLeftLetters(rootLetters);
      setRightLetters(weightLetters);
    }, 700);

    // بعد اكتمال الحركة، اعتبر الميزان قد استقر واعرض البطاقة
    setTimeout(() => {
      setMizanState("done");
      setResult(entry);
    }, 1400);
  }

  function handleReset() {
    setInput("");
    setResult(null);
    setError(null);
    setMizanState("idle");
    setLeftLetters([]);
    setRightLetters([]);
    if (inputRef.current) inputRef.current.focus();
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter") handleWeigh();
  }

  // اقتراحات سريعة
  const suggestions = ["كَتَبَ", "أَكْرَمَ", "وَسْوَسَ", "سَفْرَجَل", "اسْتَغْفَرَ", "تَغَرْغَرَ"];

  return (
    <div className="space-y-6">
      {/* العنوان */}
      <div className="text-center pt-4">
        <motion.h1
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-6xl font-bold font-cairo text-navy mb-2"
        >
          الميزان الصرفي
        </motion.h1>
        <p className="text-base md:text-lg text-muted-foreground font-cairo">
          اكتب الكلمة... واكتشف بنيتها!
        </p>
        <div className="pattern-divider w-32 mx-auto mt-4" />
      </div>

      {/* الميزان */}
      <div className="relative bg-dot-grid rounded-3xl py-6 px-4 border border-border">
        <MizanScale
          state={mizanState}
          leftLetters={leftLetters}
          rightLetters={rightLetters}
        />
      </div>

      {/* الإدخال والزر */}
      <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
        <label className="block text-sm font-semibold text-navy mb-2">
          اكتب الكلمة هنا:
        </label>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="مثال: كَتَبَ"
            className="flex-1 bg-background border border-border rounded-xl px-4 py-3 text-xl font-cairo focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold"
          />
          <button
            onClick={handleWeigh}
            disabled={!input.trim() || mizanState === "weighing"}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-navy text-white rounded-xl font-bold font-cairo hover:bg-navy/90 disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            <Scale className="w-5 h-5" />
            <span>زِن الكلمة</span>
          </button>
          {result && (
            <button
              onClick={handleReset}
              className="flex items-center justify-center gap-1 px-4 py-3 bg-muted text-navy rounded-xl font-semibold hover:bg-muted/70 transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="text-sm">كلمة جديدة</span>
            </button>
          )}
        </div>

        {/* اقتراحات سريعة */}
        {!result && !error && (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">جرّب:</span>
            {suggestions.map((s) => (
              <button
                key={s}
                onClick={() => {
                  setInput(s);
                }}
                className="text-xs font-cairo px-2 py-1 rounded-full bg-muted hover:bg-gold-soft/50 text-navy transition"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* الخطأ */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-amber-900 leading-relaxed">{error}</p>
            </div>
            <button
              onClick={() => onNavigate("dictionary")}
              className="flex-shrink-0 text-xs font-semibold text-amber-700 hover:text-amber-900 underline"
            >
              تصفّح المعجم
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* بطاقة التحليل */}
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fade-up"
          >
            <WordCard entry={result} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* أزرار سريعة للأقسام الأخرى (تظهر في الأسفل) */}
      {!result && !error && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4">
          <QuickAction
            icon={<Search className="w-5 h-5" />}
            label="معجم الكلمات"
            desc="استعرض جميع الكلمات المدروسة"
            onClick={() => onNavigate("dictionary")}
          />
          <QuickAction
            icon={<Dumbbell className="w-5 h-5" />}
            label="تحدَّ نفسك"
            desc="تدرب على الوزن بمستويات"
            onClick={() => onNavigate("training")}
          />
          <QuickAction
            icon={<HelpCircle className="w-5 h-5" />}
            label="كيف نزن؟"
            desc="تعرّف على الطريقة بالصور"
            onClick={() => onNavigate("howto")}
          />
        </div>
      )}
    </div>
  );
}

function QuickAction({
  icon,
  label,
  desc,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  desc: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="text-right bg-card border border-border rounded-xl p-4 hover:border-gold hover:shadow-md transition group"
    >
      <div className="flex items-center gap-2 mb-1">
        <span className="w-9 h-9 rounded-lg bg-navy/10 text-navy flex items-center justify-center group-hover:bg-gold group-hover:text-white transition">
          {icon}
        </span>
        <h3 className="font-bold font-cairo text-navy">{label}</h3>
      </div>
      <p className="text-xs text-muted-foreground">{desc}</p>
    </button>
  );
}

/* ========== التذييل ========== */
function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-card">
      <div className="max-w-5xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="w-4 h-4 text-gold" />
          <span>مختبر تفاعلي لشرح وتدريب الميزان الصرفي</span>
        </div>
        <div className="text-sm font-cairo text-navy">
          إعداد المعلم <span className="font-bold">أحمد يحيى الأسطل</span>
        </div>
      </div>
    </footer>
  );
}
